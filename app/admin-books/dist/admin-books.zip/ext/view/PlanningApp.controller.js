sap.ui.define(["sap/fe/core/PageController"],function(n){"use strict";return n.extend("PlanningApp.planning-app.ext.view.PlanningApp",{})});
//# sourceMappingURL=PlanningApp.controller.js.map